package com.example.devoirjee_gestioncont;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import com.example.devoirjee_gestioncont.core.bo.Genre;
import com.example.devoirjee_gestioncont.core.bo.Groupe;
import com.example.devoirjee_gestioncont.core.service.IContactService;
import com.example.devoirjee_gestioncont.core.service.IGroupeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Transactional
@SpringBootApplication
public class DevoirJeeGestionContApplication implements CommandLineRunner {

    @Autowired
    private IContactService contactService;

    @Autowired
    private IGroupeService groupeService;

    public static void main(String[] args) {
        SpringApplication.run(DevoirJeeGestionContApplication.class, args);

    }
        public void run(String... args) throws Exception {

//            Contact c1 =new Contact(null,"belarbi","hajar",null,"0618415322","0618415322","adresse1","mail1","mail2", Genre.FEMALE,new ArrayList<>());
//            Contact c11 =new Contact(null,"belarbi","farah",null,"0618415322","0618415322","adresse1","mail1","mail2", Genre.FEMALE,new ArrayList<>());
//            Contact c12 =new Contact(null,"poudaa","med",null,"0618415322","0618415322","adresse1","mail1","mail2", Genre.FEMALE,new ArrayList<>());
//            Contact c3 =new Contact(null,"boudaa","nounou",null,"0618415322","0618415322","adresse1","mail1","mail2", Genre.FEMALE,new ArrayList<>());
//            Contact c4 =new Contact(null,"bougaa","tarik",null,"0618415322","0618415322","adresse1","mail1","mail2", Genre.FEMALE,new ArrayList<>());
//            Contact c5 =new Contact(null,"belarbi","salma",null,"0618415322","0618415322","adresse1","mail1","mail2", Genre.FEMALE,new ArrayList<>());
//
//
//
//            contactService.creerContact(c1);
//            contactService.creerContact(c11);
//            contactService.creerContact(c12);
//            contactService.creerContact(c3);
//            contactService.creerContact(c4);
//            contactService.creerContact(c5);

//            Groupe g= new Groupe(null,"grp1",new ArrayList<>());
//
//            groupeService.creerGroupe(g);
//            groupeService.ajouterContactGroupe(g,c3);


        }

}
