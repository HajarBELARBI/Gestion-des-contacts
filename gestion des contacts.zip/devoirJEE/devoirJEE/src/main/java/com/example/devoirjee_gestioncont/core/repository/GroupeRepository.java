package com.example.devoirjee_gestioncont.core.repository;

import com.example.devoirjee_gestioncont.core.bo.Groupe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GroupeRepository extends JpaRepository<Groupe, Long> {
    void deleteByNom(String nm);
    Groupe findByNom(String nom);
    //optional peut etre null, on aurra pas d'exception si l'objet est null
    Optional<Groupe> findById(Long id);

    boolean existsByNom(String nom);
}

