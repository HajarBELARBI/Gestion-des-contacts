package com.example.devoirjee_gestioncont.core.web;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import com.example.devoirjee_gestioncont.core.bo.Genre;
import com.example.devoirjee_gestioncont.core.bo.Groupe;
import com.example.devoirjee_gestioncont.core.service.IContactService;
import com.example.devoirjee_gestioncont.core.service.IGroupeService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@Transactional
@Controller
@RequestMapping("/HomeGroupe")
public class GroupeController {

    protected final Logger LOGGER = Logger.getLogger(getClass());

    @Autowired
    private IGroupeService groupeService;
    @Autowired
    private IContactService contactService;

    @GetMapping
    public String Home(Model model) {

        model.addAttribute("groupes", groupeService.listGroupe());
        model.addAttribute("contacts", contactService.listContactOrdreAlpha());
        return "HomeGroupe";
    }

    @GetMapping("/deleteGroupe/{id}")
    public String deleteContact(@PathVariable("id") Long id) {
        LOGGER.info("un groupe est supprime");
        groupeService.supprimerGroupe(groupeService.chercherGroupeId(id));
        return "redirect:/HomeGroupe";
    }


    @GetMapping("/addGroupes")
    public String addForm(Model model) {
        model.addAttribute("groupe",new Groupe());
        model.addAttribute("contacts",contactService.listContactOrdreAlpha());
        return "AddGroupe";
    }





    @PostMapping("/addGroupe")
    public String Create(@RequestParam(name = "selectedContacts") ArrayList<Long> selectedContacts,
                          @ModelAttribute("groupe") Groupe groupe) {
        LOGGER.info("un groupe est cree");
        groupeService.create(groupe,selectedContacts);
        return "redirect:/HomeGroupe";
    }

    @PostMapping("/GroupByName")
    public String showGroupeByName(@RequestParam(name = "nom") String nom, Model model) {
        LOGGER.info("recherche de groupe par nom");
        model.addAttribute("groupes", groupeService.chercherGroupeNom(nom));
        model.addAttribute("contacts", contactService.listContactOrdreAlpha());
        return "listGroupe";
    }


    @GetMapping("/modifyGroupes/{id}")
    public String modifyShowForm(@PathVariable(name = "id") String id, Model model) {

        Long groupeId = Long.parseLong(id);
        model.addAttribute("contacts",contactService.listContactOrdreAlpha());
        model.addAttribute("groupe", groupeService.chercherGroupeId(groupeId));
        model.addAttribute("contCoches", groupeService.chercherGroupeId(groupeId).getListContact());
        return "UpdateFormGroupe";
    }

    @PostMapping("/modifyGroupe")
    public String modifyForm(@RequestParam(name = "selectedContacts") ArrayList<Long> selectedContacts,
                             @ModelAttribute("groupe") Groupe groupe,
                             @RequestParam("id") Long id,
                              @RequestParam("nom") String nom) {
        Groupe grp = new Groupe(id, nom, null);
        groupeService.modifierGroupe(grp,selectedContacts);
        LOGGER.info("modification d'un groupe");
        return "redirect:/HomeGroupe";
    }
}
