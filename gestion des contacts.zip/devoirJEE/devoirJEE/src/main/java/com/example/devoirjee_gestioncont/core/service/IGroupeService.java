package com.example.devoirjee_gestioncont.core.service;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import com.example.devoirjee_gestioncont.core.bo.Groupe;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Transactional
public interface IGroupeService {

    public void creerGroupe(Groupe grp);
    public void ajouterContactGroupe(Groupe grp, Contact cnt);

    public List<Groupe> listGroupe();

    public void supprimerGroupe(Groupe grp);
    public Groupe chercherGroupeNom(String nom);
    public Groupe chercherGroupeId(Long id);

    public void modifierGroupe(Groupe groupe, ArrayList<Long> contactListIds);
    void create(Groupe groupe, ArrayList<Long> contactListIds);
}
