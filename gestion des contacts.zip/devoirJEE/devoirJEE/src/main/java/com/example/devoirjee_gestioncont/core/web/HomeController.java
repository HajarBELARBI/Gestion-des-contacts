package com.example.devoirjee_gestioncont.core.web;

import com.example.devoirjee_gestioncont.core.repository.ContactRepository;
import com.example.devoirjee_gestioncont.core.repository.GroupeRepository;
import lombok.AllArgsConstructor;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@AllArgsConstructor
public class HomeController {

    @Autowired
    private final ContactRepository  contactRepository;
    @Autowired
    private final GroupeRepository groupeRepository;

    protected final Logger LOGGER = Logger.getLogger(getClass());
    @GetMapping("/test")
    public String test(){
        return "test";
    }

    @GetMapping("/home")
    public String home( Model model){
        model.addAttribute("totalContacts",contactRepository.count());
        model.addAttribute("totalGroupes",groupeRepository.count());
        return  "Home";
    }
}



