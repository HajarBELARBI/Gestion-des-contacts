package com.example.devoirjee_gestioncont.core.web;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import com.example.devoirjee_gestioncont.core.bo.Genre;
import com.example.devoirjee_gestioncont.core.service.IContactService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@Controller
@Transactional
@RequestMapping("/HomeContact")
public class ContactController {

    protected final Logger LOGGER = Logger.getLogger(getClass());
    @Autowired
    private IContactService contactService;

    @GetMapping
    public String Home(Model model) {
        model.addAttribute("contacts", contactService.listContactOrdreAlpha());
        return "HomeContact";
    }

    @PostMapping("/contactByName")
    public String showContactByName( @RequestParam(name = "nom") String nom, Model model) {
        LOGGER.info("recherche de contact par nom");
        model.addAttribute("contactList", contactService.chercherContactNom(nom));
        return "listContact";
    }

    @PostMapping("/contactByNum")
    public String showContactByNum(  @RequestParam(name = "num") String num, Model model) {
        LOGGER.info("recherche de contact par numero");
        model.addAttribute("contactList", contactService.chercherContactNum(num, num));
        return "listContact";
    }

    @GetMapping("/deleteContact/{id}")
    public String deleteContact(@PathVariable("id") Long id) {
        contactService.supprimerContact(id);
        LOGGER.info("suppression d'un contact ");
        return "redirect:/HomeContact";
    }


    @GetMapping("/modifyContacts/{id}")
    public String modifyShowForm(@PathVariable(name = "id") String id, Model model) {
        Long contactId = Long.parseLong(id);
        model.addAttribute("contact", contactService.chercherContactById(contactId));
        return "UpdateFormContact";
    }

    @PostMapping("/modifyContact")
    public String modifyForm( @RequestParam("id") Long id,
                               @RequestParam("nom") String nom,
                               @RequestParam("prenom") String prenom,
                               @RequestParam("tel1") String tel1,
                               @RequestParam("tel2") String tel2,
                               @RequestParam("adresse") String adresse,
                               @RequestParam("emailPerso") String email1,
                               @RequestParam("emailPro") String email2,
                               @RequestParam("genre") Genre genre) {
        Contact contact = new Contact(id, nom, prenom, null, tel1, tel2, adresse, email1, email2, genre,new ArrayList<>());
        contactService.modifierContact(contact);
        LOGGER.info("modification de contact ");
        return "redirect:/HomeContact";
    }

    @GetMapping("/addContacts")
    public String addForm() {
        return "AddContact";
    }


    @PostMapping("/addContact")
    public String Create( @RequestParam("nom") String nom,
                          @RequestParam("prenom") String prenom,
                          @RequestParam("tel1") String tel1,
                          @RequestParam("tel2") String tel2,
                          @RequestParam("adresse") String adresse,
                          @RequestParam("email1") String email1,
                          @RequestParam("email2") String email2,
                          @RequestParam("genre") Genre genre) {
        System.out.println(nom);
        Contact contact = new Contact(null, nom, prenom, null, tel1, tel2, adresse, email1, email2, genre,new ArrayList<>());
        contactService.creerContact(contact);
        LOGGER.info("creation de contact ");
        return "redirect:/HomeContact";
    }
}