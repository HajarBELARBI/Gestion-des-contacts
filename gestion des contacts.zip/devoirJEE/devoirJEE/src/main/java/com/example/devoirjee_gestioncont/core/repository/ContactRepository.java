package com.example.devoirjee_gestioncont.core.repository;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ContactRepository extends JpaRepository<Contact, Long> {
    void deleteById(Long id);

    List<Contact> findByNomSoundex(String nom);
    List<Contact> findByNom(String nom);

    @Override
    Optional<Contact> findById(Long aLong);

    List<Contact> findByTel1OrTel2(String tel1, String tel2);

    @Query("SELECT c FROM Contact c ORDER BY c.nom ASC")
    List<Contact> contactOrdones();


    @Transactional
    @Modifying
    @Query("UPDATE Contact  SET nomSoundex = SOUNDEX(nom)")
        //applique la methode soundex sur le non et le stocke dans la colonne nonSoundex
        void AfterSaveSoundex();
    @Query("SELECT DISTINCT(c.nomSoundex) FROM Contact c WHERE c.nom = :nom")
    String findNomSoundexByNom(String nom);
         //chercher les nons par leurs soundex

    @Override
    long count();
}
