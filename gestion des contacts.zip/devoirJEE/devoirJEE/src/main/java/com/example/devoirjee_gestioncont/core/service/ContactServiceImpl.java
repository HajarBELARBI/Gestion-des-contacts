package com.example.devoirjee_gestioncont.core.service;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import com.example.devoirjee_gestioncont.core.bo.Groupe;
import com.example.devoirjee_gestioncont.core.repository.ContactRepository;
import com.example.devoirjee_gestioncont.core.repository.GroupeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class ContactServiceImpl implements IContactService {

    @Autowired
    private ContactRepository contactRep;
    @Autowired
    private GroupeRepository groupeRep;
    @Autowired
    private IGroupeService groupeService;


    private static final int EDIT_DISTANCE_THRESHOLD = 2;
    @Override
    public void creerContact(Contact cnt) {
        Groupe group =  groupeService.chercherGroupeNom(cnt.getNom());
        if(group!= null) {
            contactRep.save(cnt);
            contactRep.AfterSaveSoundex();
            groupeService.ajouterContactGroupe(group, cnt);
        }else {
            List<Contact> contacts = contactRep.findAll();
            List<Contact> matchingContacts = new  ArrayList<>();
            for (Contact contact : contacts) {
                if (contact.getNom().equals(cnt.getNom())) {
                    matchingContacts.add(contact);
                    matchingContacts.add(cnt);
                    groupeService.creerGroupe(new  Groupe (null,cnt.getNom(),matchingContacts));
                    break;
                }
            }
            contactRep.save(cnt);
            contactRep.AfterSaveSoundex();

        }
    }

    @Override
    public List<Contact> listContactOrdreAlpha() {
        return contactRep.contactOrdones();
    }

    @Override
    public void supprimerContact(Long id) {
        contactRep.deleteById(id);
    }

    @Override
    public void modifierContact(Contact contact) {
        Optional<Contact> contactOptional = contactRep.findById(contact.getId());
        if (contactOptional.isPresent()) {
            Contact existingContact = contactOptional.get();
            existingContact.setNom(contact.getNom());
            existingContact.setPrenom(contact.getPrenom());
            existingContact.setTel1(contact.getTel1());
            existingContact.setTel2(contact.getTel2());
            existingContact.setEmailPerso(contact.getEmailPerso());
            existingContact.setEmailPro(contact.getEmailPro());
            existingContact.setAdresse(contact.getAdresse());
            existingContact.setGenre(contact.getGenre());
            contactRep.save(existingContact);
        }
        else System.out.println("not found");
    }


    @Override
    public List<Contact> chercherContactNom(String nom) {
        List<Contact> l1 = contactRep.findByNom(nom);
        List<Contact> l2 = findContactsByNameED( nom);
        List<Contact> l3 = findByNom_soundex(nom);
        Set<Contact> Contacts = new HashSet<>();
        Contacts.addAll(l1);
        Contacts.addAll(l2);
        Contacts.addAll(l3);
        List<Contact> uniqueContacts = new ArrayList<>(Contacts);
        return uniqueContacts;
    }

    @Override
    public List<Contact> chercherContactNum(String num1, String num2) {
        return contactRep.findByTel1OrTel2(num1,num2);
    }


    private int calculateEditDistance(String s1, String s2) {
        // Implémentation de l'algorithme de calcul de distance d'édition
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];
        for (int i = 0; i <= s1.length(); i++) {
            for (int j = 0; j <= s2.length(); j++) {
                if (i == 0) {
                    dp[i][j] = j;
                } else if (j == 0) {
                    dp[i][j] = i;
                } else {
//                   cost :  sub =1, sup=1,insert=1
                    int cost = (s1.charAt(i - 1) == s2.charAt(j - 1)) ? 0 : 1;
                    dp[i][j] = Math.min(Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1), dp[i - 1][j - 1] + cost);
                }
            }
        }
        return dp[s1.length()][s2.length()];
    }


    public List<Contact> findContactsByNameED(String name) {
        // 1. Obtenir tous les contacts de la base de données
        List<Contact> allContacts = contactRep.findAll();

        // 2. Filtrer les contacts avec une distance d'édition acceptable
        List<Contact> matchingContacts = new ArrayList<>();
        for(Contact contact : allContacts) {
            if(calculateEditDistance(name, contact.getNom()) <= EDIT_DISTANCE_THRESHOLD) {
                matchingContacts.add(contact);
            }
        }

        return matchingContacts;
    }


    public List<Contact> findByNom_soundex(String nomS){
        contactRep.AfterSaveSoundex();
        String a = contactRep.findNomSoundexByNom(nomS);
        return contactRep.findByNomSoundex(a);
    }

    @Override
    public void deleteContactById(Long contactId) {
        Contact contact = contactRep.findById(contactId).orElse(null);
        if (contact != null) {
            contact.getGroupes().clear(); // Remove the contact from all groups
            contactRep.save(contact); // Update the associations in the database
            contactRep.delete(contact); // Delete the contact
        }
        contactRep.deleteById(contactId);
    }
    @Override
    public Contact chercherContactById(Long contactId) {
       return contactRep.findById(contactId).get();
    }

}
