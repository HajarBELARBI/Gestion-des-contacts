package com.example.devoirjee_gestioncont.core.service;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import com.example.devoirjee_gestioncont.core.bo.Groupe;
import com.example.devoirjee_gestioncont.core.repository.ContactRepository;
import com.example.devoirjee_gestioncont.core.repository.GroupeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class GroupeServiceImlp implements IGroupeService{

    @Autowired
    private GroupeRepository groupeRep;

    @Autowired
    private ContactRepository contactRep;
    @Override
    public void creerGroupe(Groupe grp) {
        groupeRep.save(grp);
    }

    @Override
    public void ajouterContactGroupe(Groupe grp, Contact cnt) {
        Groupe groupe = groupeRep.findByNom(grp.getNom());
        Optional<Contact> contact = contactRep.findById(cnt.getId());
        groupe.getListContact().add(cnt);
        contact.get().getGroupes().add(groupe);
        groupeRep.save(groupe);
    }

    @Override
    public List<Groupe> listGroupe() {
        return groupeRep.findAll();
    }

    @Override
    public void supprimerGroupe(Groupe grp) {
        groupeRep.delete(grp);

    }

    @Override
    public Groupe chercherGroupeNom(String nom) {
        return groupeRep.findByNom(nom);
    }
    @Override
    public Groupe chercherGroupeId(Long id) {
        return groupeRep.findById(id).get();
    }

    public void create(Groupe groupe, ArrayList<Long> contactsIds) {
        if (!groupeRep.existsByNom(groupe.getNom())){
            if(contactsIds != null && !contactsIds.isEmpty()) {
                List<Contact> contacts = new ArrayList<>();
                for(Long contactId : contactsIds) {
                    System.out.println("****ajout de contact****");
                    Contact contact = contactRep.findById(contactId).get();
                    contacts.add(contact);
                }
                groupe.setListContact(contacts);
            }
            groupeRep.save(groupe);
        }
    }

    public void modifierGroupe(Groupe grp, ArrayList<Long> contactListIds) {
        Optional<Groupe> GroupeOptional = groupeRep.findById(grp.getId());
        if (GroupeOptional.isPresent()) {
            Groupe existingGroupe = GroupeOptional.get();
            existingGroupe.setNom(grp.getNom());
            List<Contact> contacts = new ArrayList<>();
            for(Long contactId : contactListIds) {
                Contact contact = contactRep.findById(contactId).get();
                contacts.add(contact);
            }
            existingGroupe.setListContact(contacts);
            groupeRep.save(existingGroupe);
        }
        else System.out.println("not found");
    }

}
