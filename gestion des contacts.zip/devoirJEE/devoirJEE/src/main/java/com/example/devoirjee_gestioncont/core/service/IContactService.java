package com.example.devoirjee_gestioncont.core.service;

import com.example.devoirjee_gestioncont.core.bo.Contact;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
@Transactional
public interface IContactService {
    public void creerContact(Contact cnt);

    public List<Contact> listContactOrdreAlpha();

    public void supprimerContact(Long id);
    public void modifierContact(Contact cnt);
    public List<Contact> chercherContactNom(String nom);
    public List<Contact> chercherContactNum(String num1,String num2);


    void deleteContactById(Long contactId);

    Contact chercherContactById(Long contactId);
}
