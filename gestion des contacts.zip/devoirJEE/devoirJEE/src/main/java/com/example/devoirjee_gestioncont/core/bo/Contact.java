package com.example.devoirjee_gestioncont.core.bo;

import jakarta.persistence.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Contact {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nom;

    private String prenom;
    private String nomSoundex;

    private String tel1;

    private String tel2;

    private String adresse;

    private String emailPerso;

    private String emailPro;
    @Enumerated(EnumType.STRING)
    private Genre genre;

    @ManyToMany(mappedBy = "listContact",cascade = CascadeType.PERSIST)
    private List<Groupe> groupes ;

    @Override
    public String toString() {
        return "Contact{" +
                "id=" + id +
                ", nom='" + nom + '\'' +
                ", nomSoundex='" + nomSoundex + '\'' +
                ", prenom='" + prenom + '\'' +
                ", tel1='" + tel1 + '\'' +
                ", tel2='" + tel2 + '\'' +
                ", adresse='" + adresse + '\'' +
                ", emailPerso='" + emailPerso + '\'' +
                ", emailPro='" + emailPro + '\'' +
                ", genre=" + genre +
                '}';
    }


}