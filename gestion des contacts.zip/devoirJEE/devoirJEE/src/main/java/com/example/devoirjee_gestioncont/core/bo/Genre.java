package com.example.devoirjee_gestioncont.core.bo;

public enum Genre {
    FEMALE,
    MALE
}
