-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2023 at 06:11 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestcontact_2`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` bigint(20) NOT NULL,
  `adresse` varchar(255) DEFAULT NULL,
  `email_perso` varchar(255) DEFAULT NULL,
  `email_pro` varchar(255) DEFAULT NULL,
  `genre` enum('FEMALE','MALE') DEFAULT NULL,
  `nom` varchar(255) DEFAULT NULL,
  `nom_soundex` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `tel1` varchar(255) DEFAULT NULL,
  `tel2` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `adresse`, `email_perso`, `email_pro`, `genre`, `nom`, `nom_soundex`, `prenom`, `tel1`, `tel2`) VALUES
(1, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'Belarbi', 'B461', 'Hajar', '0618415322', '0618415322'),
(2, 'Tanger', 'farah.belarbi@etu.uae.ac.ma', 'farah.belarbi@etu.uae.ac.ma', 'FEMALE', 'Belarbi', 'B461', 'farah', '0618415322', '0618115322'),
(3, '06, rue tamsaout hay sidi abid AL Hoceima', 'med.belarbi@etu.uae.ac.ma', 'med.belarbi@etu.uae.ac.ma', 'MALE', 'Belarbi', 'B461', 'mohammed', '0623586912', '0614758324'),
(8, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'Belarbi', 'B461', 'Hajar', '0618415322', '3366992233'),
(10, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'Belarpi', 'B461', 'Hajar', '0618415322', ''),
(12, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'Belarbi', 'B461', 'Hajar', '0618415322', ''),
(14, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'belhcen', 'B425', 'hanae', '0618415322', ''),
(15, '06, rue tamsaout hay marsa AL Hoceima', 'naoufal.rais@etu.uae.ac.ma', 'naoufal.rais@etu.uae.ac.ma', 'MALE', 'Rais', 'R200', 'Naoufal', '0650214463', '0650214463'),
(16, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'Rais', 'R200', 'manar', '0618415322', '0618415322'),
(17, '06, rue tamsaout hay sidi abid AL Hoceima', 'fatiha.adahri@etu.uae.ac.ma', 'fatiha.adahri@etu.uae.ac.ma', 'FEMALE', 'Adahri', 'A360', 'Fatiha', '0618415322', '0632451542'),
(19, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'bel', 'B400', 'Hajar', '0618415322', ''),
(20, '06, rue tamsaout hay sidi abid AL Hoceima', 'hajar.belarbi@etu.uae.ac.ma', 'hajar.belarbi@etu.uae.ac.ma', 'FEMALE', 'bel', 'B400', 'Hajar', '0618415322', '');

-- --------------------------------------------------------

--
-- Table structure for table `groupe`
--

CREATE TABLE `groupe` (
  `id` bigint(20) NOT NULL,
  `nom` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `groupe`
--

INSERT INTO `groupe` (`id`, `nom`) VALUES
(1, 'Belarbi'),
(2, 'belhcen'),
(3, 'jee'),
(4, 'Rais'),
(5, 'Adahri'),
(6, 'darkaoui'),
(7, 'bel');

-- --------------------------------------------------------

--
-- Table structure for table `groupe_list_contact`
--

CREATE TABLE `groupe_list_contact` (
  `groupes_id` bigint(20) NOT NULL,
  `list_contact_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `groupe_list_contact`
--

INSERT INTO `groupe_list_contact` (`groupes_id`, `list_contact_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 10),
(1, 12),
(2, 13),
(2, 14),
(4, 15),
(4, 16),
(5, 17),
(6, 8),
(6, 14),
(6, 15),
(3, 1),
(3, 13),
(3, 15),
(7, 19),
(7, 20);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupe`
--
ALTER TABLE `groupe`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groupe_list_contact`
--
ALTER TABLE `groupe_list_contact`
  ADD KEY `FKl0nwkcqrlpd939brc4syqgby` (`groupes_id`),
  ADD KEY `FKd7y6wcjcxcm59ltay3j8i9bqf` (`list_contact_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `groupe`
--
ALTER TABLE `groupe`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `groupe_list_contact`
--
ALTER TABLE `groupe_list_contact`
  ADD CONSTRAINT `FKd7y6wcjcxcm59ltay3j8i9bqf` FOREIGN KEY (`list_contact_id`) REFERENCES `contact` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FKl0nwkcqrlpd939brc4syqgby` FOREIGN KEY (`groupes_id`) REFERENCES `groupe` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
